num = ARGV[0].to_i
for i in (1..num)    
    for b in (1..i)
        print b
    end
    print " "
end